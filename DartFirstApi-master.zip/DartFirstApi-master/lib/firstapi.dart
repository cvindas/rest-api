/// firstapi
///
/// A Aqueduct web server.
library firstapi;

export 'dart:async';
export 'dart:io';

export 'package:aqueduct/aqueduct.dart';

export 'firstapi_sink.dart';
