import { combineReducers } from "redux";
import leads from "./leads";

export default combineReducers({
  leads
});
