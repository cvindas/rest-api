# Lead Manager

> Full stack Django/React/Redux app

Info: This app and YouTube series is not yet finished. I will be making commits as videos are released

## Quick Start

```bash
# Install dependencies
npm install

# Serve API on localhost:8000
python leadmanager/manage.py runserver

# Run webpack (from root)
npm run dev

# Build for production
npm run build
```
