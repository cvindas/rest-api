# Typescript Photo Gallery API
This project is a simple web server written in Typescript using Nodejs and Mongodb, with the purpose to store images for Client Applications like web applications or mobile apps.

# Installation
```
git clone https://github.com/FaztTech/photo-gallery-api
cd photo-gallery-api
npm install
npm start
```