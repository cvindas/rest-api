# REST API using Typescript

- mongodb / mongoose
- express / node