# AndroidRest
Use JSON on Android Example

Ejemplo de peticion REST en android usando HttpUrlConnection de Java
