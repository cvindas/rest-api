package com.azteca.developers.json;

/**
 * Created by Neksze on 02/10/2015.
 */
public class Person {

    private String Name;
    private String City;
    private String Country;

    public String getCity() {
        return City;
    }

    public String getCountry() {
        return Country;
    }

    public String getName() {
        return Name;
    }
}
